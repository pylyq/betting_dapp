# betting_dapp
This is a simple betting app built with solidity, truffle and react.
